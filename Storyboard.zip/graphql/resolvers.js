const User = require("../models/User");
const Room = require("../models/Room");

module.exports = {
  createRoom: async (args, req) => {
    return "lol";
  }
};
