const initialState = {
  loading: true,
  error: null,
  rooms: null,
  room: {
    loading: true,
    roomdata: null
  }
};

export default (state = initialState, action) => {
  const { type, payload } = action;
  switch (type) {
    case "GET_ROOMS": {
      return {
        ...state,
        loading: false,
        rooms: payload
      };
    }
    case "POST_ROOM":
    case "GET_ROOM": {
      return {
        ...state,
        room: {
          ...state.room,
          loading: false,
          roomdata: payload
        }
      };
    }
    case "NEW_MESSAGE": {
      return {
        ...state,
        room: {
          ...state.room,
          loading: false,
          roomdata: {
            ...state.room.roomdata,
            room: payload
          }
        }
      };
    }
    default: {
      return state;
    }
  }
};
