import React from "react";
import PropTypes from "prop-types";

const Navbar = props => {
  return (
    <div className="header-container">
      <div className="header">
        <div className="header-logo">
          <img src=""></img>
        </div>
        asdasdasdasd
      </div>
    </div>
  );
};

Navbar.propTypes = {};

export default Navbar;
