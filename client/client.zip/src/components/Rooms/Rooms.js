import React, { useEffect, Fragment } from "react";
import PropTypes from "prop-types";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import { connect } from "react-redux";
import RoomHeader from "./RoomHeader";
import { getRooms } from "../../actions/roomActions";

const Rooms = ({ getRooms, rooms: { rooms, loading } }) => {
  useEffect(() => {
    getRooms();
  }, [getRooms]);

  const hej = message => {
    console.log("hej");
  };

  return (
    <div className="room-container">
      <RoomHeader />
      <Link to="/createroom">
        <button className="message-button">Create Room</button>
      </Link>
      <div className="full-room-container">
        <div className="room-title">
          <div className="room-list-titles-header">
            <div className="room-list-part">
              <h3>Roomname</h3>
            </div>

            <div className="room-list-part">
              <h3>Inputs</h3>
            </div>
            <div className="room-list-part">
              <h3>Number of Players</h3>
            </div>
            <div className="room-list-part">
              <h3>Status</h3>
            </div>
          </div>
          {!loading && rooms ? (
            rooms.room.map(room => (
              <div className="room-list-titles">
                <Link to={`/room/${room.roomname}`}>
                  <div className="room-list-part">
                    <p>{room.ownroomname}</p>
                  </div>
                  {room.messages ? (
                    <div className="room-list-part">
                      <p>{room.messages.length}</p>
                    </div>
                  ) : (
                    <Fragment>asdasd</Fragment>
                  )}
                  <div className="room-list-part">
                    <p>23</p>
                  </div>
                  <div className="room-list-part">
                    <p>
                      {/* om det är samma längd på room messages som maxsettings är rummet färdigt */}
                      {room.messages.length === room.messageSettings.maxMessages
                        ? "Finished"
                        : "Ongoing"}
                    </p>
                  </div>
                </Link>
              </div>
            ))
          ) : (
            <div>loading</div>
          )}
        </div>
        <div className="room-user">asdasdasdasd</div>
      </div>
    </div>
  );
};

Rooms.propTypes = {};

const mapStateToProps = state => {
  return {
    rooms: state.rooms
  };
};

export default connect(
  mapStateToProps,
  {
    getRooms
  }
)(Rooms);
